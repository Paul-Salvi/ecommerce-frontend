

function FormError(props) {
    return (
        <p className="text-red-500 text-xs ">{props.error}</p>

    );
}
export default FormError;
function Text({ icon, text }) {
    return (
        <span className="mt-1" >{text}</span>
    );
}
export default Text;
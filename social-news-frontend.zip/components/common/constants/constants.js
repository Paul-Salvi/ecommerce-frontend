export const FooterContent = [{
    heading: 'Policy',
    one: 'Terms And Condition',
    two: 'Return',
    three: 'Shipping',
    four: 'Privacy'
},
{
    heading: 'Category',
    one: 'Laptop',
    two: 'Mobile',
    three: 'Other Electronics',
    four: 'Laptop Accessories'
}, {
    heading: 'Contact',
    one: 'C-26/35 B-1',
    two: 'Ramkatora, Lahurabir',
    three: 'Varanasi-221001',
    four: 'No 0542-2203753'
}
];
export const policy = 'policy'
export const category = 'category'
export const contact = 'contact'
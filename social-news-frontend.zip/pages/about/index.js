import Layout from '../../components/common/layout/index'

function About() {
  return (
    <Layout>
    <div>
       about page
   </div>
 </Layout>
  
  )
}

export default About